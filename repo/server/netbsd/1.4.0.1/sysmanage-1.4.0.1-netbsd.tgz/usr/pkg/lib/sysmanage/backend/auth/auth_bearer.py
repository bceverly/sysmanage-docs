"""
This module ise used to verify the JWT token we use for authentication
"""

from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from backend.auth.auth_handler import decode_jwt
from backend.i18n import _


class JWTBearer(HTTPBearer):
    """
    This is a subclass of the FastAPI HTTPBearer class that is used to manage
    authentication via JWT
    """

    def __init__(self, auto_error: bool = True):
        """
        We are turning on auto_error here
        """
        super().__init__(auto_error=auto_error)

    async def __call__(self, request: Request):
        """
        This function verifies the JWT token as well as the overall
        credential scheme used.
        """
        credentials: HTTPAuthorizationCredentials = await super().__call__(request)
        if credentials:
            if credentials.scheme != "Bearer":
                raise HTTPException(
                    status_code=403, detail=_("Invalid authentication scheme.")
                )
            if not self.verify_jwt(credentials.credentials):
                raise HTTPException(status_code=401, detail=_("Expired token."))

            return credentials.credentials

        raise HTTPException(status_code=403, detail=_("Invalid authorization code."))

    def verify_jwt(self, jwtoken: str) -> bool:
        """
        This function decodes and verifies the JWT token
        """
        is_token_valid: bool = False

        try:
            payload = decode_jwt(jwtoken)
        except (ValueError, TypeError, KeyError):
            payload = None
        if payload:
            is_token_valid = True

        return is_token_valid


async def get_current_user(  # NOSONAR
    token: str = Depends(JWTBearer()),
) -> str:
    """
    Extract the current user's userid from the JWT token.
    """
    try:
        payload = decode_jwt(token)
        if payload and "user_id" in payload:
            return payload["user_id"]
    except (ValueError, TypeError, KeyError):
        pass

    raise HTTPException(status_code=401, detail=_("Could not validate credentials"))
