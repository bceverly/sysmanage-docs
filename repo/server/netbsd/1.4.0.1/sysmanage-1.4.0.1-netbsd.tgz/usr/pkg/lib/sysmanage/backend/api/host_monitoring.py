"""
Host monitoring endpoints for certificates, roles, and service control.
This module handles endpoints related to monitoring aspects of hosts.
"""

import asyncio
import logging
from datetime import timezone
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import sessionmaker

from backend.api.host_utils import validate_host_approval_status
from backend.api.error_constants import error_host_not_found
from backend.auth.auth_bearer import JWTBearer, get_current_user
from backend.i18n import _
from backend.persistence import db, models
from backend.security.roles import SecurityRoles
from backend.utils.verbosity_logger import sanitize_log
from backend.websocket.messages import create_command_message
from backend.websocket.queue_enums import QueueDirection
from backend.websocket.queue_operations import QueueOperations

router = APIRouter()
queue_ops = QueueOperations()
logger = logging.getLogger(__name__)


class ServiceControlRequest(BaseModel):
    """
    Service control request model for starting, stopping, or restarting services.
    """

    action: str  # "start", "stop", or "restart"
    services: List[str]  # List of service names to control


def _get_host_certificates_sync(host_id: str):
    """
    Synchronous helper function to retrieve host certificates.
    This runs in a thread pool to avoid blocking the event loop.
    """
    # Get the SQLAlchemy session
    session_local = sessionmaker(  # pylint: disable=duplicate-code
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        # Find the host
        host = session.query(models.Host).filter(models.Host.id == host_id).first()

        if not host:
            raise HTTPException(status_code=404, detail=error_host_not_found())

        validate_host_approval_status(host)

        # Get certificates for this host
        certificates = (
            session.query(models.HostCertificate)
            .filter(models.HostCertificate.host_id == host_id)
            .order_by(
                models.HostCertificate.not_after.asc()
            )  # Order by expiration date
            .all()
        )

        # Convert to dictionary format for JSON response
        certificate_data = []
        for cert in certificates:
            certificate_data.append(
                {
                    "id": cert.id,
                    "certificate_name": cert.certificate_name,
                    "subject": cert.subject,
                    "issuer": cert.issuer,
                    "not_before": (
                        cert.not_before.replace(tzinfo=timezone.utc).isoformat()
                        if cert.not_before
                        else None
                    ),
                    "not_after": (
                        cert.not_after.replace(tzinfo=timezone.utc).isoformat()
                        if cert.not_after
                        else None
                    ),
                    "serial_number": cert.serial_number,
                    "fingerprint_sha256": cert.fingerprint_sha256,
                    "is_ca": cert.is_ca,
                    "key_usage": cert.key_usage,
                    "file_path": cert.file_path,
                    "collected_at": (
                        cert.collected_at.replace(tzinfo=timezone.utc).isoformat()
                        if cert.collected_at
                        else None
                    ),
                    "is_expired": cert.is_expired,
                    "days_until_expiry": cert.days_until_expiry,
                    "common_name": cert.common_name,
                }
            )

        return {
            "host_id": host_id,
            "fqdn": host.fqdn,
            "total_certificates": len(certificate_data),
            "certificates": certificate_data,
        }


@router.get("/host/{host_id}/certificates", dependencies=[Depends(JWTBearer())])
async def get_host_certificates(host_id: str):
    """
    Get SSL certificates collected from a host.
    Runs the database query in a thread pool to avoid blocking the event loop.
    """
    # Run the synchronous database operation in a thread pool
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _get_host_certificates_sync, host_id)


@router.post(
    "/host/{host_id}/request-certificates-collection",
    dependencies=[Depends(JWTBearer())],
)
async def request_certificates_collection(host_id: str):
    """
    Request an agent to collect SSL certificates from the system.
    This sends a message via WebSocket to the agent requesting certificate collection.
    """
    logger.info(
        "CERTIFICATE COLLECTION: Endpoint called for host_id: %s", sanitize_log(host_id)
    )

    # Get the SQLAlchemy session
    session_local = sessionmaker(  # pylint: disable=duplicate-code
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        # Find the host
        host = session.query(models.Host).filter(models.Host.id == host_id).first()

        if not host:
            logger.warning("CERTIFICATE COLLECTION: Host not found: %s", host_id)
            raise HTTPException(status_code=404, detail=error_host_not_found())

        logger.info(
            "CERTIFICATE COLLECTION: Found host %s (fqdn: %s)", host_id, host.fqdn
        )

        validate_host_approval_status(host)

        # Create command message for certificate collection request
        command_message = create_command_message(
            command_type="collect_certificates", parameters={}
        )

        logger.info(
            "CERTIFICATE COLLECTION: Created command message: %s", command_message
        )

        # Send command to agent via message queue
        queue_ops.enqueue_message(
            message_type="command",
            message_data=command_message,
            direction=QueueDirection.OUTBOUND,
            host_id=host_id,
            db=session,
        )
        # Commit the session to persist the queued message
        session.commit()

        logger.info(
            "CERTIFICATE COLLECTION: Successfully requested certificate collection for host: %s",
            host_id,
        )
        return {"result": True, "message": _("Certificate collection requested")}


def _get_host_roles_sync(host_id: str):
    """
    Synchronous helper function to retrieve host roles.
    This runs in a thread pool to avoid blocking the event loop.
    """
    # Get the SQLAlchemy session
    session_local = sessionmaker(  # pylint: disable=duplicate-code
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        # Find the host
        host = session.query(models.Host).filter(models.Host.id == host_id).first()

        if not host:
            raise HTTPException(status_code=404, detail=error_host_not_found())

        validate_host_approval_status(host)

        # Get roles for this host
        roles = (
            session.query(models.HostRole)
            .filter(models.HostRole.host_id == host_id)
            .order_by(models.HostRole.role.asc(), models.HostRole.package_name.asc())
            .all()
        )

        # Convert to dictionary format for JSON response
        role_data = []
        for role in roles:
            role_data.append(
                {
                    "id": role.id,
                    "role": role.role,
                    "package_name": role.package_name,
                    "package_version": role.package_version,
                    "service_name": role.service_name,
                    "service_status": role.service_status,
                    "is_active": role.is_active,
                    "detected_at": (
                        role.detected_at.replace(tzinfo=timezone.utc).isoformat()
                        if role.detected_at
                        else None
                    ),
                    "updated_at": (
                        role.updated_at.replace(tzinfo=timezone.utc).isoformat()
                        if role.updated_at
                        else None
                    ),
                }
            )

        return {
            "host_id": host_id,
            "fqdn": host.fqdn,
            "total_roles": len(role_data),
            "roles": role_data,
        }


@router.get("/host/{host_id}/roles", dependencies=[Depends(JWTBearer())])
async def get_host_roles(host_id: str):
    """
    Get server roles detected on a host.
    Runs the database query in a thread pool to avoid blocking the event loop.
    """
    # Run the synchronous database operation in a thread pool
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _get_host_roles_sync, host_id)


@router.post(
    "/host/{host_id}/request-roles-collection",
    dependencies=[Depends(JWTBearer())],
)
async def request_roles_collection(host_id: str):
    """
    Request an agent to collect server roles from the system.
    This sends a message via WebSocket to the agent requesting role collection.
    """
    logger.info(
        "ROLE COLLECTION: Endpoint called for host_id: %s", sanitize_log(host_id)
    )

    # Get the SQLAlchemy session
    session_local = sessionmaker(  # pylint: disable=duplicate-code
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        # Find the host
        host = session.query(models.Host).filter(models.Host.id == host_id).first()

        if not host:
            raise HTTPException(status_code=404, detail=error_host_not_found())

        validate_host_approval_status(host)

        # Create command message for role collection request
        command_message = create_command_message(
            command_type="collect_roles", parameters={}
        )

        logger.info("ROLE COLLECTION: Created command message: %s", command_message)

        # Send command to agent via message queue
        queue_ops.enqueue_message(
            message_type="command",
            message_data=command_message,
            direction=QueueDirection.OUTBOUND,
            host_id=host_id,
            db=session,
        )
        # Commit the session to persist the queued message
        session.commit()

        logger.info(
            "ROLE COLLECTION: Successfully requested role collection for host: %s",
            host_id,
        )

        return {"result": True, "message": _("Role collection requested")}


@router.post("/host/{host_id}/service-control", dependencies=[Depends(JWTBearer())])
async def control_services(
    host_id: str,
    request: ServiceControlRequest,
    current_user: str = Depends(get_current_user),
):
    """
    Control services on a host (start, stop, restart).
    This sends a command via WebSocket to the agent to control the specified services.
    """
    logger.info(
        "SERVICE CONTROL: Endpoint called for host_id: %s, action: %s, services: %s",
        sanitize_log(host_id),
        sanitize_log(request.action),
        sanitize_log(request.services),
    )

    # Validate action
    if request.action not in ["start", "stop", "restart"]:
        raise HTTPException(
            status_code=400,
            detail=_("Invalid action. Must be 'start', 'stop', or 'restart'"),
        )

    # Validate services list
    if not request.services:
        raise HTTPException(status_code=400, detail=_("No services specified"))

    # Get the SQLAlchemy session
    session_local = sessionmaker(  # pylint: disable=duplicate-code
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        # Check if user has permission for the requested action
        user = (
            session.query(models.User)
            .filter(models.User.userid == current_user)
            .first()
        )
        if not user:
            raise HTTPException(status_code=401, detail=_("User not found"))

        if user._role_cache is None:
            user.load_role_cache(session)

        # Check specific role based on action
        if request.action == "start":
            if not user.has_role(SecurityRoles.START_HOST_SERVICE):
                raise HTTPException(
                    status_code=403,
                    detail=_("Permission denied: START_HOST_SERVICE role required"),
                )
        elif request.action == "stop":
            if not user.has_role(SecurityRoles.STOP_HOST_SERVICE):
                raise HTTPException(
                    status_code=403,
                    detail=_("Permission denied: STOP_HOST_SERVICE role required"),
                )
        elif request.action == "restart":
            if not user.has_role(SecurityRoles.RESTART_HOST_SERVICE):
                raise HTTPException(
                    status_code=403,
                    detail=_("Permission denied: RESTART_HOST_SERVICE role required"),
                )

        # Find the host
        host = session.query(models.Host).filter(models.Host.id == host_id).first()

        if not host:
            raise HTTPException(status_code=404, detail=error_host_not_found())

        validate_host_approval_status(host)

        # Check if host is running in privileged mode
        if not host.is_agent_privileged:
            raise HTTPException(
                status_code=403,
                detail=_("Host must be running in privileged mode for service control"),
            )

        # Create command message for service control
        command_message = create_command_message(
            command_type="service_control",
            parameters={"action": request.action, "services": request.services},
        )

        logger.info("SERVICE CONTROL: Created command message: %s", command_message)

        # Send command to agent via message queue
        queue_ops.enqueue_message(
            message_type="command",
            message_data=command_message,
            direction=QueueDirection.OUTBOUND,
            host_id=host_id,
            db=session,
        )
        # Commit the session to persist the queued message
        session.commit()

        logger.info(
            "SERVICE CONTROL: Successfully requested %s for services %s on host: %s",
            sanitize_log(request.action),
            sanitize_log(request.services),
            sanitize_log(host_id),
        )

        return {
            "result": True,
            "message": _("Service {} requested for {} services").format(
                request.action, len(request.services)
            ),
            "action": request.action,
            "services": request.services,
        }
