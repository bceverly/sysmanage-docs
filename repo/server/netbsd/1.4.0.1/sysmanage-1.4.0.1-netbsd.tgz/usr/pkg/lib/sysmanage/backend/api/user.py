"""
This module contains the API implementation for the user object in the system.
"""

import asyncio
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Optional

from argon2 import PasswordHasher
from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel, EmailStr
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import sessionmaker

from backend.api.error_constants import error_user_not_found
from backend.api.profile import validate_and_process_image
from backend.auth.auth_bearer import JWTBearer, get_current_user
from backend.auth.auth_handler import decode_jwt
from backend.config import config
from backend.i18n import _
from backend.persistence import db, models
from backend.security.login_security import login_security
from backend.security.roles import SecurityRoles
from backend.services.audit_service import ActionType, AuditService, EntityType, Result

# Import will be added at runtime to avoid circular imports

if TYPE_CHECKING:
    from backend.api.password_reset import (
        create_password_reset_token,
        send_initial_setup_email,
    )

argon2_hasher = PasswordHasher()

router = APIRouter()


class User(BaseModel):
    """
    This class represents the JSON payload to the /user POST/PUT requests.
    """

    active: bool
    userid: EmailStr
    password: Optional[str] = None  # Optional for new user creation
    first_name: Optional[str] = None
    last_name: Optional[str] = None


@router.delete("/user/{user_id}", dependencies=[Depends(JWTBearer())])
async def delete_user(user_id: str, current_user: str = Depends(get_current_user)):
    """
    This function deletes a single user given an id
    """

    # Get the SQLAlchemy session
    session_local = sessionmaker(
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        # Check if user has permission to delete users
        auth_user = (
            session.query(models.User)
            .filter(models.User.userid == current_user)
            .first()
        )
        if not auth_user:
            raise HTTPException(status_code=401, detail=error_user_not_found())

        if auth_user._role_cache is None:
            auth_user.load_role_cache(session)

        if not auth_user.has_role(SecurityRoles.DELETE_USER):
            raise HTTPException(
                status_code=403,
                detail=_("Permission denied: DELETE_USER role required"),
            )

        # See if we were passed a valid id
        users = session.query(models.User).filter(models.User.id == user_id).all()

        # Check for failure
        if len(users) != 1:
            raise HTTPException(status_code=404, detail=error_user_not_found())

        deleted_user = users[0]
        # Extract values before deletion to avoid ObjectDeletedError
        deleted_userid = deleted_user.userid

        # Delete the record
        session.query(models.User).filter(models.User.id == user_id).delete()
        session.commit()

        # Audit log user deletion
        AuditService.log_delete(
            db=session,
            user_id=auth_user.id,
            username=current_user,
            entity_type=EntityType.USER,
            entity_id=user_id,
            entity_name=deleted_userid,
        )

    return {"result": True}


@router.get("/user/permissions", dependencies=[Depends(JWTBearer())])
async def get_user_permissions(current_user: str = Depends(get_current_user)):
    """
    Get the current user's security role permissions.
    Returns a dictionary of role names to boolean values.
    """
    session_local = sessionmaker(
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        # Find the user
        user = (
            session.query(models.User)
            .filter(models.User.userid == current_user)
            .first()
        )

        if not user:
            raise HTTPException(status_code=401, detail=error_user_not_found())

        # Load role cache
        user.load_role_cache(session)

        # Build permissions dictionary for all known roles
        permissions = {}
        for role in SecurityRoles:
            permissions[role.value] = user.has_role(role)

        return {"is_admin": user.is_admin, "permissions": permissions}


@router.get("/user/me", dependencies=[Depends(JWTBearer())])
async def get_logged_in_user(request: Request):
    """
    This function retrieves the user record for the currently logged in
    user.
    """
    # Get the current userid
    userid = ""
    if "Authorization" in request.headers:
        token = request.headers.get("Authorization")
        the_elements = token.split()
        if len(the_elements) == 2:
            old_dict = decode_jwt(the_elements[1])
            if old_dict and "user_id" in old_dict:
                userid = old_dict["user_id"]

    # Check for special case admin user
    the_config = config.get_config()
    admin_userid = the_config.get("security", {}).get("admin_userid")
    if admin_userid and userid == admin_userid:
        ret_user = models.User(
            id=0,
            active=True,
            userid=userid,
            is_locked=False,
            failed_login_attempts=0,
            locked_at=None,
        )
        return ret_user

    # Get the SQLAlchemy session
    session_local = sessionmaker(
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        users = session.query(models.User).filter(models.User.userid == userid).all()

        # Check for failure
        if len(users) != 1:
            raise HTTPException(status_code=404, detail=error_user_not_found())

        ret_user = models.User(
            id=users[0].id,
            active=users[0].active,
            userid=users[0].userid,
            first_name=users[0].first_name,
            last_name=users[0].last_name,
            is_locked=users[0].is_locked,
            failed_login_attempts=users[0].failed_login_attempts,
            locked_at=users[0].locked_at,
        )

        return ret_user


@router.get("/user/{user_id}", dependencies=[Depends(JWTBearer())])
async def get_user(user_id: str):
    """
    This function retrieves a single user by its id
    """

    # Get the SQLAlchemy session
    session_local = sessionmaker(
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        users = session.query(models.User).filter(models.User.id == user_id).all()

        # Check for failure
        if len(users) != 1:
            raise HTTPException(status_code=404, detail=error_user_not_found())

        ret_user = models.User(
            id=users[0].id,
            active=users[0].active,
            userid=users[0].userid,
            first_name=users[0].first_name,
            last_name=users[0].last_name,
            is_locked=users[0].is_locked,
            failed_login_attempts=users[0].failed_login_attempts,
            locked_at=users[0].locked_at,
        )

        return ret_user


@router.get("/user/by_userid/{userid}", dependencies=[Depends(JWTBearer())])
async def get_user_by_userid(userid: str):
    """
    This function retrieves a single user by userid
    """

    # Get the SQLAlchemy session
    session_local = sessionmaker(
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        users = session.query(models.User).filter(models.User.userid == userid).all()

        # Check for failure
        if len(users) != 1:
            raise HTTPException(status_code=404, detail=error_user_not_found())

        ret_user = models.User(
            id=users[0].id,
            active=users[0].active,
            userid=users[0].userid,
            first_name=users[0].first_name,
            last_name=users[0].last_name,
            is_locked=users[0].is_locked,
            failed_login_attempts=users[0].failed_login_attempts,
            locked_at=users[0].locked_at,
        )

        return ret_user


def _get_all_users_sync():
    """
    Synchronous helper function to retrieve all users.
    This runs in a thread pool to avoid blocking the event loop.
    """
    # Get the SQLAlchemy session
    session_local = sessionmaker(
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        result = session.query(models.User).all()

        ret_users = []
        for user in result:
            the_user = models.User(
                id=user.id,
                active=user.active,
                userid=user.userid,
                first_name=user.first_name,
                last_name=user.last_name,
                last_access=user.last_access,
                is_locked=user.is_locked,
                failed_login_attempts=user.failed_login_attempts,
                locked_at=user.locked_at,
            )
            ret_users.append(the_user)

        return ret_users


@router.get("/users", dependencies=[Depends(JWTBearer())])
async def get_all_users():
    """
    This function retrieves all users in the system.
    Runs the database query in a thread pool to avoid blocking the event loop.
    """
    # Run the synchronous database operation in a thread pool
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _get_all_users_sync)


@router.post("/user", dependencies=[Depends(JWTBearer())])
async def add_user(
    new_user: User, request: Request, current_user: str = Depends(get_current_user)
):
    """
    This function adds a new user to the system.
    """
    # Get the SQLAlchemy session
    session_local = sessionmaker(
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    # Add the data to the database
    with session_local() as session:
        # Check if user has permission to add users
        auth_user = (
            session.query(models.User)
            .filter(models.User.userid == current_user)
            .first()
        )
        if not auth_user:
            raise HTTPException(status_code=401, detail=error_user_not_found())

        if auth_user._role_cache is None:
            auth_user.load_role_cache(session)

        if not auth_user.has_role(SecurityRoles.ADD_USER):
            raise HTTPException(
                status_code=403, detail=_("Permission denied: ADD_USER role required")
            )

        # See if the caller is trying to add a user that already exists
        check_duplicate = (
            session.query(models.User)
            .filter(models.User.userid == new_user.userid)
            .all()
        )
        if len(check_duplicate) > 0:
            raise HTTPException(status_code=409, detail=_("User already exists"))

        # This is a unique user.  Proceed...
        # If password is provided, use it; otherwise use a placeholder that forces reset
        if new_user.password:
            hashed_value = argon2_hasher.hash(new_user.password)
        else:
            # Use a random placeholder password that user cannot guess
            import secrets

            placeholder_password = secrets.token_urlsafe(32)
            hashed_value = argon2_hasher.hash(placeholder_password)

        user = models.User(
            userid=new_user.userid,
            active=new_user.active,
            first_name=new_user.first_name,
            last_name=new_user.last_name,
            hashed_password=hashed_value,
            last_access=datetime.now(timezone.utc).replace(tzinfo=None),
        )
        session.add(user)
        session.commit()

        # Audit log user creation
        AuditService.log_create(
            db=session,
            user_id=auth_user.id,
            username=current_user,
            entity_type=EntityType.USER,
            entity_id=str(user.id),
            entity_name=str(new_user.userid),
            details={
                "active": new_user.active,
                "first_name": new_user.first_name,
                "last_name": new_user.last_name,
            },
        )

        # Import here to avoid circular imports
        from backend.api.password_reset import (
            create_password_reset_token,
            send_initial_setup_email,
        )

        # If no password was provided, create a password reset token and send initial setup email
        if not new_user.password:
            reset_token = create_password_reset_token(user.id, session)
            send_initial_setup_email(str(user.userid), reset_token, request)

        ret_user = models.User(
            id=user.id,
            active=user.active,
            userid=user.userid,
            is_locked=user.is_locked,
            failed_login_attempts=user.failed_login_attempts,
            locked_at=user.locked_at,
        )

        return ret_user


@router.put("/user/{user_id}", dependencies=[Depends(JWTBearer())])
async def update_user(
    user_id: str, user_data: User, current_user: str = Depends(get_current_user)
):
    """
    This function updates an existing user by id
    """

    # Get the SQLAlchemy session
    session_local = sessionmaker(
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    # Update the user
    with session_local() as session:
        # Check if user has permission to edit users
        auth_user = (
            session.query(models.User)
            .filter(models.User.userid == current_user)
            .first()
        )
        if not auth_user:
            raise HTTPException(status_code=401, detail=error_user_not_found())

        if auth_user._role_cache is None:
            auth_user.load_role_cache(session)

        if not auth_user.has_role(SecurityRoles.EDIT_USER):
            raise HTTPException(
                status_code=403, detail=_("Permission denied: EDIT_USER role required")
            )

        # See if we were passed a valid id
        users = session.query(models.User).filter(models.User.id == user_id).all()

        # Check for failure
        if len(users) != 1:
            raise HTTPException(status_code=404, detail=error_user_not_found())

        # No need to check for userid duplicates explicitly - the database unique constraint will handle this

        # Update the values
        hashed_value = argon2_hasher.hash(user_data.password)
        try:
            session.query(models.User).filter(models.User.id == user_id).update(
                {
                    models.User.active: user_data.active,
                    models.User.userid: user_data.userid,
                    models.User.first_name: user_data.first_name,
                    models.User.last_name: user_data.last_name,
                    models.User.hashed_password: hashed_value,
                    models.User.last_access: datetime.now(timezone.utc),
                }
            )
            session.commit()

            # Audit log user update
            AuditService.log_update(
                db=session,
                user_id=auth_user.id,
                username=current_user,
                entity_type=EntityType.USER,
                entity_id=user_id,
                entity_name=str(user_data.userid),
                details={
                    "active": user_data.active,
                    "first_name": user_data.first_name,
                    "last_name": user_data.last_name,
                },
            )
        except IntegrityError as exc:
            session.rollback()
            raise HTTPException(
                status_code=409, detail=_("User already exists")
            ) from exc

        # Get updated user data to return current lock status
        updated_user = (
            session.query(models.User).filter(models.User.id == user_id).first()
        )
        ret_user = models.User(
            id=user_id,
            active=user_data.active,
            userid=user_data.userid,
            is_locked=updated_user.is_locked,
            failed_login_attempts=updated_user.failed_login_attempts,
            locked_at=updated_user.locked_at,
        )

    return ret_user


@router.post("/user/{user_id}/unlock", dependencies=[Depends(JWTBearer())])
async def unlock_user(user_id: str, current_user: str = Depends(get_current_user)):
    """
    This function unlocks a user account manually
    """
    # Get the SQLAlchemy session
    session_local = sessionmaker(
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        # Check if user has permission to unlock users
        auth_user = (
            session.query(models.User)
            .filter(models.User.userid == current_user)
            .first()
        )
        if not auth_user:
            raise HTTPException(status_code=401, detail=error_user_not_found())

        if auth_user._role_cache is None:
            auth_user.load_role_cache(session)

        if not auth_user.has_role(SecurityRoles.UNLOCK_USER):
            raise HTTPException(
                status_code=403,
                detail=_("Permission denied: UNLOCK_USER role required"),
            )

        # See if we were passed a valid id
        user = session.query(models.User).filter(models.User.id == user_id).first()

        # Check for failure
        if not user:
            raise HTTPException(status_code=404, detail=error_user_not_found())

        # Unlock the account
        login_security.unlock_user_account(user, session)

        ret_user = models.User(
            id=user.id,
            active=user.active,
            userid=user.userid,
            is_locked=user.is_locked,
            failed_login_attempts=user.failed_login_attempts,
            locked_at=user.locked_at,
        )

    return ret_user


@router.post("/user/{user_id}/lock", dependencies=[Depends(JWTBearer())])
async def lock_user(user_id: str, current_user: str = Depends(get_current_user)):
    """
    This function locks a user account manually
    """
    # Get the SQLAlchemy session
    session_local = sessionmaker(
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        # Check if user has permission to lock users
        auth_user = (
            session.query(models.User)
            .filter(models.User.userid == current_user)
            .first()
        )
        if not auth_user:
            raise HTTPException(status_code=401, detail=error_user_not_found())

        if auth_user._role_cache is None:
            auth_user.load_role_cache(session)

        if not auth_user.has_role(SecurityRoles.LOCK_USER):
            raise HTTPException(
                status_code=403, detail=_("Permission denied: LOCK_USER role required")
            )

        # See if we were passed a valid id
        user = session.query(models.User).filter(models.User.id == user_id).first()

        # Check for failure
        if not user:
            raise HTTPException(status_code=404, detail=error_user_not_found())

        # Lock the account
        login_security.lock_user_account(user, session)

        ret_user = models.User(
            id=user.id,
            active=user.active,
            userid=user.userid,
            is_locked=user.is_locked,
            failed_login_attempts=user.failed_login_attempts,
            locked_at=user.locked_at,
        )

    return ret_user


@router.post("/user/{user_id}/image", dependencies=[Depends(JWTBearer())])
async def upload_user_profile_image(user_id: str, file: UploadFile = File(...)):
    """
    Upload a profile image for a specific user (admin function).

    Security features:
    - File size limit (5MB) to prevent DoS attacks
    - Image format validation
    - Automatic resizing to prevent excessive storage usage
    - Image processing to ensure valid image data
    """
    # Validate file is provided
    if not file:
        raise HTTPException(status_code=400, detail=_("No file provided"))

    # Read file content
    try:
        file_content = await file.read()
    except Exception as exc:
        raise HTTPException(
            status_code=400, detail=_("Error reading uploaded file")
        ) from exc

    # Validate and process the image using the same function as profile.py
    processed_image_bytes, image_format = validate_and_process_image(
        file_content, file.filename or "image"
    )

    # Get the SQLAlchemy session
    session_local = sessionmaker(
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        # Find the user by id
        user = session.query(models.User).filter(models.User.id == user_id).first()

        if not user:
            raise HTTPException(status_code=404, detail=error_user_not_found())

        # Update user's profile image
        user.profile_image = processed_image_bytes
        user.profile_image_type = image_format
        user.profile_image_uploaded_at = datetime.now(timezone.utc).replace(tzinfo=None)

        session.commit()

        return {
            "message": _("Profile image uploaded successfully"),
            "image_format": image_format,
            "uploaded_at": user.profile_image_uploaded_at,
        }


@router.get("/user/{user_id}/image", dependencies=[Depends(JWTBearer())])
async def get_user_profile_image(user_id: str):
    """
    Get a specific user's profile image (admin function).
    """
    # Get the SQLAlchemy session
    session_local = sessionmaker(
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        # Find the user by id
        user = session.query(models.User).filter(models.User.id == user_id).first()

        if not user:
            raise HTTPException(status_code=404, detail=error_user_not_found())

        if not user.profile_image:
            raise HTTPException(status_code=404, detail=_("No profile image found"))

        # Determine content type based on stored format
        content_type = f"image/{user.profile_image_type}"
        if user.profile_image_type == "jpg":
            content_type = "image/jpeg"

        return Response(
            content=user.profile_image,
            media_type=content_type,
            headers={
                "Cache-Control": "public, max-age=3600",  # Cache for 1 hour
                "Last-Modified": (
                    user.profile_image_uploaded_at.strftime("%a, %d %b %Y %H:%M:%S GMT")
                    if user.profile_image_uploaded_at
                    else datetime.now(timezone.utc).strftime(
                        "%a, %d %b %Y %H:%M:%S GMT"
                    )
                ),
            },
        )


@router.delete("/user/{user_id}/image", dependencies=[Depends(JWTBearer())])
async def delete_user_profile_image(user_id: str):
    """
    Delete a specific user's profile image (admin function).
    """
    # Get the SQLAlchemy session
    session_local = sessionmaker(
        autocommit=False, autoflush=False, bind=db.get_engine()
    )

    with session_local() as session:
        # Find the user by id
        user = session.query(models.User).filter(models.User.id == user_id).first()

        if not user:
            raise HTTPException(status_code=404, detail=error_user_not_found())

        if not user.profile_image:
            raise HTTPException(status_code=404, detail=_("No profile image to delete"))

        # Clear the profile image data
        user.profile_image = None
        user.profile_image_type = None
        user.profile_image_uploaded_at = None

        session.commit()

        return {"message": _("Profile image deleted successfully")}
