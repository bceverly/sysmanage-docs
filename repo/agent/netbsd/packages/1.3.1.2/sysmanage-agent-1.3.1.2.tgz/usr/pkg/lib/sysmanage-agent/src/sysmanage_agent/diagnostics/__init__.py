"""Diagnostics collection module."""
