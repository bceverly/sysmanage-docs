# SysManage Agent - OpenBSD Port Installation

This package contains the OpenBSD port infrastructure for sysmanage-agent.

## Quick Start Installation

### Step 1: Extract to Ports Tree

```bash
# Extract the port files to the OpenBSD ports tree
doas tar xzf sysmanage-agent-0.9.7.7-openbsd-port.tar.gz \
    -C /usr/ports/sysutils/

# Rename to expected directory name
doas mv /usr/ports/sysutils/sysmanage-agent /usr/ports/sysutils/sysmanage-agent.old 2>/dev/null || true
doas mv /usr/ports/sysutils/openbsd-port /usr/ports/sysutils/sysmanage-agent

# Or if you prefer, extract directly:
cd /usr/ports/sysutils/
doas rm -rf sysmanage-agent
doas tar xzf ~/sysmanage-agent-0.9.7.7-openbsd-port.tar.gz
doas mv openbsd-port sysmanage-agent
```

### Step 2: Build and Install

```bash
# Navigate to the port directory
cd /usr/ports/sysutils/sysmanage-agent

# Install Python dependencies (avoid gcc conflicts)
doas pkg_add py3-websockets py3-yaml py3-aiohttp py3-cryptography \
    py3-sqlalchemy py3-alembic

# Generate checksums for the source tarball
doas make makesum

# Build and install the port
doas make install

# Verify installation
ls -la /usr/local/libexec/sysmanage-agent/
```

### Step 3: Configure and Start

```bash
# Copy example configuration
doas cp /usr/local/share/examples/sysmanage-agent/sysmanage-agent.yaml \
    /etc/sysmanage-agent.yaml

# Edit configuration with your server details
doas vi /etc/sysmanage-agent.yaml

# Enable and start the service
doas rcctl enable sysmanage_agent
doas rcctl start sysmanage_agent

# Check service status
doas rcctl check sysmanage_agent
doas rcctl status sysmanage_agent

# View logs
doas tail -f /var/log/sysmanage-agent/sysmanage-agent.log
```

## Configuration

The configuration file is located at `/etc/sysmanage-agent.yaml`.

Required settings:
- `server.url`: WebSocket URL of your SysManage server
- `server.token`: Authentication token from your SysManage server

Database path (OpenBSD convention):
- `/var/db/sysmanage-agent/agent.db`

## Service Management

```bash
# Start service
doas rcctl start sysmanage_agent

# Stop service
doas rcctl stop sysmanage_agent

# Restart service
doas rcctl restart sysmanage_agent

# Check if running
doas rcctl check sysmanage_agent

# Enable on boot
doas rcctl enable sysmanage_agent

# Disable on boot
doas rcctl disable sysmanage_agent
```

## Troubleshooting

### Service won't start

Check the rc.d script and logs:

```bash
# View rc.d script
cat /etc/rc.d/sysmanage_agent

# Test manually
doas /usr/local/bin/python3 /usr/local/libexec/sysmanage-agent/main.py

# Check permissions
ls -la /var/db/sysmanage-agent/
ls -la /var/log/sysmanage-agent/
```

### Check installation

```bash
# Verify installed files
pkg_info -L sysmanage-agent

# Check Python modules
/usr/local/bin/python3 -c "import websockets, yaml, aiohttp"
```

## Uninstallation

```bash
# Stop and disable service
doas rcctl stop sysmanage_agent
doas rcctl disable sysmanage_agent

# Uninstall the port
cd /usr/ports/sysutils/sysmanage-agent
doas make uninstall

# Remove configuration and data (optional)
doas rm -f /etc/sysmanage-agent.yaml
doas rm -rf /var/db/sysmanage-agent/
doas rm -rf /var/log/sysmanage-agent/
```

## Documentation

- **Full Documentation**: See README.md in this package
- **Submission Guide**: See SUBMISSION.md for official ports tree submission
- **OpenBSD Porter's Handbook**: https://www.openbsd.org/faq/ports/

## Support

- **GitHub Issues**: https://github.com/bceverly/sysmanage-agent/issues
- **OpenBSD Ports**: ports@openbsd.org

---

**Version:** 0.9.7.7
**Platform:** OpenBSD 7.4+
**Architecture:** amd64 (primary), others may work
